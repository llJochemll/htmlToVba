Hoe te gebruiken:
1.	Maak je html voor 1 rij
2. 	Vervang text door @@@fldNaam@@@
3.	Plaats ### rond herhalend gedeelte

vb:
<!DOCTYPE html>
<html>
<head>
    <meta name="author" content="Jochem" />
    <meta charset="UTF-8">
    <title>voorbeeld</title>
</head>
<body>
###
	<a>@@@fldTelefoonnummer@@@</a>
###
</body>
</html>

4.	Open het programma
5.	Volg de stappen
6. 	Kopie�r de code in een VBA sub
7.	Klaar